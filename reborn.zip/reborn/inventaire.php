<?php 
session_start();
if(isset($_SESSION['connected']) && ($_SESSION['connected'] == "yes")){
include("top_header.php");
?>
<?php
// lecture fichier          ----------------------------------------------------
$inventory = file_get_contents('http://192.168.200.20/reborn/inventory.info');
$lines = explode("\n", $inventory);
// Vérification IP existante ----------------------------------------------------

?>
<div class="container">
    <div id="font-image" class="pull-right hidden-xs hidden-sm">
      <img src="<?php echo $config['url_path']; ?>src/background.png"  />
    </div>
<br>
<br>
<div class="row">
  <div class="col-md-12">
   <div class="row">
    <div class="col-md-1">
    </div>      
    <div class="col-md-10">
      <legend style="text-align: left;">Inventaire automatique</legend>
	Ces péripheriques ont été trouvés mais ne sont pas présent dans la base

      <table class="table table-condensed">
        <tr><th>Equipements</td><td>Action</td></tr>
        <?php foreach($lines as $line){ 
	  if(!empty($line)){
          $data = explode(";", $line);

          $host = $bdd->query("SELECT hostname FROM hosts WHERE hostname='$data[0]'");
	  $ip='';
	  foreach($host as $h){ $ip=$h['hostname']; }
	  if(empty($ip)) {
          ?>
        <tr>
          <td>IP : <?php echo $data[0]; ?> <br> OS : <?php echo $data[1]; ?><br> HOSTNAME : <?php echo $data[2]; ?></td>
          <td><a href="<?php echo $config['url_path']; ?>/reborn/devices.php?add&hostname=<?php echo $data[2]; ?>&ip=<?php echo $data[0]; ?>&infosystem=<?php echo $data[1]; ?>"><button type="button" class="btn btn-success">Ajouter</button></a></td>
        </tr>
        <?php }}} ?>
        <input type="hidden" name="action" id="action" value="add" />   
      </table>
    </div>
    <div class="col-md-1">
    </div>
   </div>
  </div>
 </div>
<div>
<?php }else{ header('Location: ./login.php'); } ?>

<?php 
session_start();
if(isset($_SESSION['connected']) && ($_SESSION['connected'] == "yes")){
include("top_header.php");
?>
<div class="container">
    <div id="font-image" class="pull-right hidden-xs hidden-sm">
      <img src="<?php echo $config['url_path']; ?>src/background.png"  />
    </div>
<br>
<br>
<script src="src/JsBarcode.all.js"></script>
<script>
	Number.prototype.zeroPadding = function(){
		var ret = "" + this.valueOf();
		return ret.length == 1 ? "0" + ret : ret;
	};
</script>
<div class="row">
  <div class="col-md-12">
   <div class="row">
    <div class="col-md-1">
    </div>      
    <div class="col-md-10">
      <legend style="text-align: left;">Liste des équipements et consommables</legend>

      <table class="table table-bordered">
        <tr class="active"><th>Equipements</td><td>Type</td><td>Code Barre</td></tr>
        <?php 
          $list = $bdd->query("SELECT  description,name,code_barre FROM hosts,host_template WHERE hosts.host_template_id = host_template.id");
		  $devices = $bdd->query("SELECT  description,nom as name,devices.code_barre as code_barre FROM devices,hosts where devices.id_device = hosts.id");
		foreach($list as $hosts){
          ?>
        <tr>
          <td><?php echo $hosts['description']; ?></td>
          <td><?php echo $hosts['name']; ?></td>
		  <td><img id="<?php echo $hosts['code_barre']; ?>"/><script>JsBarcode("#<?php echo $hosts['code_barre']; ?>", "<?php echo $hosts['code_barre']; ?>");</script></td>
        </tr>
        <?php }
		foreach($devices as $hosts){
          ?>
        <tr>
          <td><?php echo $hosts['description']; ?></td>
          <td><?php echo $hosts['name']; ?></td>
		  <td><img id="<?php echo $hosts['code_barre']; ?>"/><script>JsBarcode("#<?php echo $hosts['code_barre']; ?>", "<?php echo $hosts['code_barre']; ?>");</script></td>
        </tr>
        <?php } ?>
      </table>
    </div>
    <div class="col-md-1">
    </div>
   </div>
  </div>
 </div>
</div>
<?php }else{ header('Location: ./login.php'); } ?>

<?php 
include("./include/auth.php");
include("./include/top_header.php");

if(isset($_POST['form'])){
	
	
}

?>

<div class="container">
	
		<div id="font-image" class="pull-right hidden-xs hidden-sm">
			<img src="<?php echo $config['url_path']; ?>src/background.png"  />
		</div>
		<form action="devices.php">
		
		<legend style="text-align: left;">Editer Equipement</legend>

		<?php /*$hosts = db_fetch_assoc('SELECT host.id as id, host.description as description,host_template.name as tmpname,status FROM host,host_template WHERE host.host_template_id=host_template.id ORDER BY id');
		foreach($hosts as $host) {

			$img = "null";
			$dashboard = "windows-linux-devices";
			if ($host['tmpname'] == 'Raspberry') {
				$img = "raspi.png";
			}
			if ($host['tmpname'] == 'Windows_10_Desktop') {
				$img = "ordifixwindows.png";
			}
			if ($host['tmpname'] == 'Linux_Desktop') {
				$img = "ordifixlinux.png";
			}
			if ($host['tmpname'] == 'Windows_10_Laptop') {
				$img = "laptopwindows.png";
			}
			if ($host['tmpname'] == 'Windows_7_Desktop') {
				$img = "ordifixwindows7.png";
			}
			if ($host['tmpname'] == 'Windows_7_Laptop') {
				$img = "laptopwindows7.png";
			}
			if ($host['tmpname'] == 'Linux_Laptop') {
				$img = "laptoplinux.png";
			}
			if ($host['tmpname'] == 'Android') {
				$img = "phoneandroid.png";
				$dashboard = "android-devices";
			}
			if ($host['tmpname'] == 'Cisco_Router') {
				$img = "cisco.png";
			}

			if ($host['disabled'] == 'on') {
				$class = "default";
			} else {
				if ($host['status'] == '0') {
					$class = "info";
				}
				if ($host['status'] == '1') {
					$class = "danger";
				}
				if ($host['status'] == '2') {
					$class = "warning";
				}
				if ($host['status'] == '3') {
					$class = "success";
				}
			}
		}
		*/

		?>
		
			<label>Name:</label>
            <input type="text" id="Name" name="Name" required="required" maxlength="255" class="form-control " placeholder="Nom" />
            </br>

            <label>Adresse:</label>
            <input type="text" id="adresse" name="adresse" required="required" maxlength="255" class="form-control " placeholder="adresse" />
            </br>
			
			<label>Template:</label>
            <input type="text" id="Template" name="Template" required="required" maxlength="255" class="form-control " placeholder="Template" />
            </br>
			
			<label>SNMP Comunnity:</label>
            <input type="text" id="snmpcommune" name="snmpcommune" required="required" maxlength="255" class="form-control " placeholder="snmpcommune" />
            </br>
			
			<label>SNMP Version:</label>
			 <select id="snmpversion" name="snmpversion" required="required" class="form-control">
			  <option value="1">1</option>
			  <option value="2c">2c</option>
			</select> 
            </br>
			
			<label>SNMP Port:</label>
            <input type="number" id="snmpport" name="snmpport" required="required" maxlength="255" class="form-control" placeholder="161" />
            </br>
		
		
		</form>
		
</div>
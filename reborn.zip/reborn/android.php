<?php
$username = $_SESSION['user'];
$password = $_GET['password'];
if(isset($password) AND ($password == 'inventory78')){
$bdd = new PDO('mysql:host=localhost;dbname=cacti', 'cacti', 'cpir');
	$insert = $bdd->prepare("SELECT * from hosts WHERE code_barre = :barcode LIMIT 1");
	$data = $insert->execute(array('barcode'=>$_GET['barcode']));
	$row = $insert->fetch();
	if(!empty($row)){

		echo $row["code_barre"] ."µ". $row["description"] ."µ". $row["hostname"] ."µ". $row["snmp_community"] ."µ". $row["version_systeme"];
	}else{
		echo "erreur";
	}
}

//echo $data;
//$insert = $bdd->query("SELECT * from hosts WHERE code_barre = '.$_GET['barcode'].' LIMIT 1");
//$data = $insert->execute();
//$row = $insert->fetch();
?>